<?php 
    return [
        "titulo-especial" => "Viaje especial",
        "nombre" => "Nombre completo",
        "telefono" => "Teléfono",
        "salida" => "Salida",
        "hora" => "Hora",
        "llegada"  => "Llegada",
        "info-vuelo" => "Información de vuelo",        
        "de" => "De",
        "a" => "A",
        "zona" => "Zona",
        "pasajeros" => "Pasajeros",
        "metodo-pago" => "Metodo de pago",
        "efectivo" => "Efectivo",
        "monto" => "Monto",
        "comentarios" => "Comentarios"
    ];