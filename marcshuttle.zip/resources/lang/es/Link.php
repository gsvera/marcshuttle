<?php
    return [
        "about" => "acerca-de-nosotros"
    ];