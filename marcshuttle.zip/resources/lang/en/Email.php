<?php
    return [
        "titulo-especial" => "Custom trip",
        "nombre" => "Full name",
        "telefono" => "Phone",
        "salida" => "Departure",
        "hora" => "Hour",
        "llegada" => "Arrival",
        "info-vuelo" => "Info flight",
        "de" => "From",
        "a" => "To",
        "zona" => "Area",
        "pasajeros" => "Pax",
        "metodo-pago" => "Payment method",
        "efectivo" => "Cash",
        "monto" => "Amount",
        "comentarios" => "Comments"
    ];