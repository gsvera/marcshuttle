
<?php $__env->startSection('content'); ?>
<div class="layer-about back-slider-thanks"></div>
<div class="row elementup m-0 col-12 col-md-12 text-center align-center" style="height:370px;">
    <h1 class="font-weight-bold text-white fsize-xl"><?php echo e(__('Home.gracias')); ?></h1>    
    <p class="text-white font-wwight-bold fsize-sm">
        <?php echo e(__('Home.texto-gracias-uno')); ?>

        <br>
        <?php echo e(__('Home.texto-gracias-dos')); ?>: <?php echo e($folio); ?>

    </p>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        //  actualiza boton menu para el home
        document.getElementById('btbMenuBook').setAttribute('href', '/')
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marcshuttle\resources\views/web/thanks.blade.php ENDPATH**/ ?>