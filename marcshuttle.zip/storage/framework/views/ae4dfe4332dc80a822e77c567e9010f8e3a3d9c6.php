<?php
    $lang = App::getLocale();
    $prefijo = "";

    if($lang == 'en')
    {
        $prefijo = '/en/';
    }
    else{
        $prefijo = '/';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.standalone.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/intlTelInput.css')); ?>">
    <script type="text/javascript" src="/js/intlTelInput.js"></script>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css"> -->
    <script src="https://use.fontawesome.com/97a88bff0a.js"></script>
    <!-- <link href="https://kit-pro.fontawesome.com/releases/v5.15.3/css/pro.min.css" type="text/css" rel="stylesheet"> -->
    <title>Marc Shuttle</title>
    <!-- <script type="text/javascript">
        window.CSRF_TOKEN = '<?php echo e(csrf_token()); ?>';
    </script> -->
    <?php echo $__env->yieldContent('metas'); ?>

    <?php echo $__env->yieldContent('headers'); ?>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div class="azul-nav d-flex">
        <ul class="nav col">
            <li class="nav-item mr-3">
                <a href="mailto:marcshuttlec@gmail.com" class="text-white-menu nav-link">
                    <i class="fa fa-envelope" aria-hidden="true"></i> marcshuttlec@gmail.com
                </a>
            </li>
        </ul>
        <ul class="nav col row">
            <li class="nav-item" style="text-align:right;">
                <a class="nav-link text-white-menu" href="#">
                    <i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e(__('Home.ubicacion-nav')); ?>

                </a>
            </li>
        </ul>
    </div>
    <nav class="transparent-nav d-flex" id="header">
        <div class="col-md-2 d-flex" style="align-items:center;">
            <a href="<?php echo e($prefijo); ?>">
                <img width="50%" src="/img/logos/Logo-Marcshuttle.webp" alt="Logo">
            </a>
        </div>
        <ul class="nav justify-content-end col-md-9" style="align-items:center;">
            <li class="nav-item">
                <a href="<?php echo e(url($prefijo)); ?>" class="nav-link text-white-menu-lg"><?php echo e(__('Home.home')); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white-menu-lg" href="javascript:void(0)"><?php echo e(__('Home.destinos')); ?></a>
                <ul class="sub-menu">
                    <li><a class="text-white-menu-lg font-weight-bold" style="text-decoration:none;" href="<?php echo e(__('Playa.url')); ?>">Playa del carmen</a></li>
                    <li><a class="text-white-menu-lg font-weight-bold" style="text-decoration:none;" href="<?php echo e(__('Tulum.url')); ?>">Tulum</a></li>
                    <li><a class="text-white-menu-lg font-weight-bold" style="text-decoration:none;" href="<?php echo e(url(__('Bacalar.url'))); ?>">Bacalar</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white-menu-lg" href="<?php echo e(url(__('Tours.url'))); ?>">Tours</a>
            </li>
            <!-- <li class="nav-item">
                <a href="<?php echo e(url($prefijo.__('Link.about'))); ?>" class="nav-link text-white-menu-lg"><?php echo e(__('Home.acerca-nosotros')); ?></a>
            </li> -->
            <li class="mx-3">
                <a href="tel:9981224280" class="nav-link text-white-menu-lg">
                    <span class="back-orange"><i class="fa fa-phone" aria-hidden="true"></i></span> +52 998-122-4280
                </a>
            </li>
            <li>
                <div >
                    <a class="btn btn-outline-white" href="#motorbusqueda" id="btbMenuBook">
                        <?php echo e(__('Home.btn-menu-reserva')); ?>

                    </a>
                </div>
            </li>
        </ul>
        
        <div class="d-flex col-md-1 mx-3" stlye="align-items-center;">
            <button class="btn" onclick="changeLenguage('<?php echo e($lang=='en'?'es':'en'); ?>')">
                <?php if($lang=='es'): ?>
                  <img src="/img/assets/eng.png" alt="ingles" width="35" />
                <?php else: ?>
                  <img src="/img/assets/esp.png" alt="español" width="35" />
                <?php endif; ?>
            </button>
        </div>
    </nav>
    <!-- MENU PARA MOBILE -->
    <nav class="nav-mobile" id="navMobile">
        <div class="br-bt-gray col-12 d-flex py-3">
            <div class="col-2 justify-content-center align-center d-flex">
                <div>
                    <button class="btn btn-orange" onclick="ShowHideMenu()"><i id="icon-menu" class="fa fa-bars" aria-hidden="true"></i></button>
                </div>
            </div>
            <div class="col-4 d-flex justify-content-center">
                <a href="<?php echo e($prefijo); ?>">
                    <img width="90%" src="/img/logos/Logo-Marcshuttle.webp" alt="Logo">
                </a>
            </div>
            <div class="col-4 justify-content-center align-center d-flex">
                <button class="btn btn-outline-white">Request cuote</button>
            </div>
            <div class="d-flex col-1" stlye="align-items-center;">
                <button class="btn" onclick="changeLenguage('<?php echo e(App::getLocale()=='en'?'es':'en'); ?>')">
                    <?php if(App::getLocale()=='es'): ?>
                    <img src="/img/assets/eng.png" alt="ingles" width="35" />
                    <?php else: ?>
                    <img src="/img/assets/esp.png" alt="español" width="35" />
                    <?php endif; ?>
                </button>
            </div>
        </div>
        <div class="sub-menu-hide" id="submenuhide" style="display:none;">
            <ul class="nav-mobile-hide">
                <li class="nav-item">
                    <a class="text-orange-menu" href="<?php echo e(url($prefijo)); ?>"><?php echo e(__('Home.home')); ?></a>
                </li>
                <li class="nav-item sub-menu-hv">
                    <a class="text-orange-menu" href="javascript:void(0)"><?php echo e(__('Home.destinos')); ?></a>
                    <ul class="sub-menu-mb">
                        <li><a class="text-gray font-weight-bold" style="text-decoration:none;" href="<?php echo e(url(__('Playa.url'))); ?>">Playa del carmen</a></li>
                        <li><a class="text-gray font-weight-bold" style="text-decoration:none;" href="<?php echo e(url(__('Tulum.url'))); ?>">Tulum</a></li>
                        <li><a class="text-gray font-weight-bold" style="text-decoration:none;" href="<?php echo e(url(__('Bacalar.url'))); ?>">Bacalar</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="text-orange-menu" href="<?php echo e(url(__('Tours.url'))); ?>">Tours</a>
                </li>
                <!-- <li class="nav-item">
                    <a class="text-orange-menu"><?php echo e(__('Home.acerca-nosotros')); ?></a>
                </li> -->
            </ul>
        </div>
    </nav>

    <!-- END MENU PARA MOBILE -->
    <div>
        <?php echo $__env->yieldContent('content'); ?>        
    </div>
    <!-- <div class="div-angule">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" class="angule-blue">
            <path class="elementor-shape-fill" d="M500.2,94.7L0,0v100h1000V0L500.2,94.7z" style="transform-origin: center;transform: rotateY(0deg)"></path>
        </svg>
    </div> -->
    <div class="triangule-blue"></div>
    <div class="back-footer pt-5" style="bottom:0">
        <div class="row px-5 justify-content-center mx-0 col-12 col-md-12 mx-auto">
            <!-- <div class="col-md-1"></div> -->
            <div class="col-12 col-md-3">
                <h4 class="text-white font-weight-bold"><?php echo e(__('Home.translados-footer')); ?></h4>
                <p class="text-gray fsize-sm text-justify"><?php echo e(__('Home.text-footer')); ?></p>                
            </div>
            <div class="col-12 col-md-3">
                <h4 class="text-white font-weight-bold"><?php echo e(__('Home.contactanos')); ?></h4>
                <ul class="none-list">
                    <li class="text-gray fsize-sm">768 Market Street San Francisco, <br /> CA 64015, United States</li>
                    <li class="fsize-sm">
                        <a href="mailto:marcshuttlec@gmail.com" class="text-gray-link without-link">
                            marcshuttlec@gmail.com
                        </a>
                    </li>
                    <li class="text-gray fsize-sm">
                        <a href="tel:9981224280" class="text-gray-link without-link">
                            (+52) 998 122 4280
                        </a>
                    </li>
                </ul>
                <!-- <ul class="none-list">
                    <li class="text-gray fsize-sm">
                        
                        <?php echo e(__('Home.acerca-nosotros')); ?>

                    </li>
                    <li class="text-gray fsize-sm"><?php echo e(__('Home.servicio-cliente')); ?></li>
                    <li class="text-gray fsize-sm">Bus Type</li>
                    <li class="text-gray fsize-sm"><?php echo e(__('Home.privacidad-politica')); ?></li>
                    <li class="text-gray fsize-sm"><?php echo e(__('Home.terminos-condiciones')); ?></li>
                </ul> -->
            </div>
            <div class="col-12 col-md-3">
                <h4 class="text-white font-weight-bold"><?php echo e(__('Home.enlaces')); ?></h4>
                <ul class="none-list">
                    <li class="text-gray fsize-sm">
                        <a href="<?php echo e(url(__('Playa.url'))); ?>" class="text-gray-link fsize-sm without-link">
                            <?php echo e(__('Home.translado-playa')); ?>

                        </a>
                    </li>
                    <li class="text-gray fsize-sm">
                        <a href="<?php echo e(url(__('Tulum.url'))); ?>" class="text-gray-link fsize-sm without-link">
                            <?php echo e(__('Home.traslado-tulum')); ?>

                        </a>
                    </li>
                    <li class="text-gray fsize-sm">
                        <a href="<?php echo e(url(__('Bacalar.url'))); ?>" class="text-gray-link fsize-sm without-link">
                            <?php echo e(__('Home.traslado-bacalar')); ?>

                        </a>
                    </li>
                    <li class="text-gray fsize-sm">
                        <a href="<?php echo e(url(__('Tours.url'))); ?>" class="text-gray-link fsize-sm without-link">
                            Tours
                        </a>
                    </li>
                    <li class="text-gray fsize-sm">
                        <a href="#" class="text-gray-link fsize-sm without-link">
                            <?php echo e(__('Home.politicas-privacidad')); ?>

                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-md-2">
                <h4 class="text-white font-weight-bold"><?php echo e(__('Home.metodo-pago')); ?></h4>
                <i class="fa fa-cc-paypal text-white fa-2x mx-1" aria-hidden="true"></i>
                <i class="fa fa-money text-white fa-2x mx-1" aria-hidden="true"></i>
            </div>
            <!-- <div class="col-md-1"></div> -->
        </div>
        <div class="divider"></div>
        <div class="footer-extend py-4 px-5">
            <div class="col-12 col-md-6">
                <a href="https://huella-digital.mx/" class="text-gray-link px-5 fsize-sm font-weight-bold without-link">
                    © 2023 Marc Shuttle. Powered by Huella digital
                </a>
            </div>
            <div class="col-12 col-md-6 d-flex justify-content-end px-5">
                <div class="text-center">
                    <a href="<?php echo e($prefijo); ?>">
                        <img width="15%" src="/img/logos/Logo-Marcshuttle.webp" alt="Logo">
                    </a>
                </div>
            </div>
        </div>
        <div class="footer-extend-2">
            <div class="col-12 text-center">
                <a href="https://huella-digital.mx/" class="text-gray-link px-5 fsize-sm font-weight-bold without-link">
                    © 2023 Marc Shuttle. Powered by Huella digital
                </a>
            </div>
            <div class="col text-center py-3" style="align-items:center;">
            <a href="<?php echo e($prefijo); ?>">
                <img width="50%" src="/img/logos/Logo-Marcshuttle.webp" alt="Logo">
            </a>
            </div>
        </div>
    </div>
    <a rel="nofollow" target="_blank" style="text-decoration:none;" href="https://wa.me/+529981224280">
        <img class="chat-icon" src="/img/icons/whatsapp-icon.png" alt="icono chat whatsapp">
    </a>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- <script src="<?php echo e(asset('js/jquery-3.3.1.js')); ?>"></script> -->
    <script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('js/bootstrap-select.js')); ?>"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script> -->
    <script src="<?php echo e(asset('js/alerts.js')); ?>"></script>
    <script type="text/javascript">
        let countMenu = 1;
        $(function(){
            if(screen.width > 640){
                $(window).scroll(function(){
                    if($(window).scrollTop() > 20){
                        $('#header').removeClass('transparent-nav')
                        $('#header').addClass('transparent-nav-blue')
                    }
                    else if($(window).scrollTop() < 20){
                        $('#header').addClass('transparent-nav')
                        $('#header').removeClass('transparent-nav-blue')
                    }
                })
            }
            else if(screen.width < 640){
                $(window).scroll(function(){
                    if($(window).scrollTop() > 1){
                        $('#navMobile').removeClass('nav-mobile')
                        $('#navMobile').addClass('nav-mobile-blue')
                    }
                    else if($(window).scrollTop() < 1){
                        $('#navMobile').addClass('nav-mobile')
                        $('#navMobile').removeClass('nav-mobile-blue')
                    }
                })
                $('#footer-extend').css({'display':'none'})
            }
        })

        function ShowHideMenu()
        {            
            if(countMenu == 1)
            {
                $('#submenuhide').slideDown()
                $('#icon-menu').removeClass('fa-bars')
                $('#icon-menu').addClass('fa-times')
                countMenu = 0
            }
            else if(countMenu == 0){
                $('#submenuhide').slideUp()
                $('#icon-menu').addClass('fa-bars')
                $('#icon-menu').removeClass('fa-times')
                countMenu = 1
            }
        }

    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\marcshuttle\resources\views/web/layouts/layout.blade.php ENDPATH**/ ?>